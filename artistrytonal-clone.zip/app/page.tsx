import Header from "@/components/header"
import CategoryNav from "@/components/category-nav"
import HeroCarousel from "@/components/hero-carousel"
import ArtSection from "@/components/art-section"

export default function Home() {
  return (
    <main className="min-h-screen bg-background">
      <Header />
      <CategoryNav />
      <HeroCarousel />

      <div className="container mx-auto px-4 py-8 space-y-12">
        <ArtSection title="Arts" items={artsData} />

        <ArtSection title="Gaming" items={gamingData} />

        <ArtSection title="Membership" items={membershipData} />

        <ArtSection title="Pfps" items={pfpsData} />
      </div>
    </main>
  )
}

const artsData = [
  {
    id: 1,
    title: "undead pasillo",
    image: "/dark-fantasy-undead-warrior-red-glow.jpg",
    floorPrice: "1.6",
    usdtPrice: "26411",
  },
  {
    id: 2,
    title: "TV Head Character",
    image: "/cyberpunk-tv-head-mask-horns.jpg",
    floorPrice: "2",
    usdtPrice: "49013",
  },
  {
    id: 3,
    title: "Caricature of James",
    image: "/muscular-superhero-moon-background.jpg",
    floorPrice: "1.5",
    usdtPrice: "26015",
  },
  {
    id: 4,
    title: "castle",
    image: "/dark-gothic-castle-fantasy.jpg",
    floorPrice: "1.2",
    usdtPrice: "24685",
  },
]

const gamingData = [
  {
    id: 5,
    title: "Peace of mind",
    image: "/serene-meditation-nature-scene.jpg",
    floorPrice: "9",
    usdtPrice: "538092",
  },
  {
    id: 6,
    title: "Waker Robot_PAII",
    image: "/futuristic-robot-mech-warrior.jpg",
    floorPrice: "4",
    usdtPrice: "516026",
  },
  {
    id: 7,
    title: "Laptop in a room",
    image: "/cozy-room-laptop-setup-ambient.jpg",
    floorPrice: "2",
    usdtPrice: "58013",
  },
  {
    id: 8,
    title: "The Cathedral",
    image: "/gothic-cathedral-architecture-dramatic.jpg",
    floorPrice: "1.5",
    usdtPrice: "56015",
  },
]

const membershipData = [
  {
    id: 9,
    title: "Ziya",
    image: "/elegant-portrait-woman-artistic.jpg",
    floorPrice: "3.5",
    usdtPrice: "514023",
  },
  {
    id: 10,
    title: "Falling Pink Doll",
    image: "/surreal-pink-doll-falling-artistic.jpg",
    floorPrice: "2.2",
    usdtPrice: "59815",
  },
  {
    id: 11,
    title: "Mothers love",
    image: "/mother-child-emotional-portrait.jpg",
    floorPrice: "6.3",
    usdtPrice: "525241",
  },
  {
    id: 12,
    title: "aaloor",
    image: "/abstract-artistic-portrait-colorful.jpg",
    floorPrice: "4",
    usdtPrice: "516026",
  },
]

const pfpsData = [
  {
    id: 13,
    title: "Colorful Dog Portrait",
    image: "/colorful-dog-portrait-artistic-paint.jpg",
    floorPrice: "2.8",
    usdtPrice: "412023",
  },
  {
    id: 14,
    title: "Abstract Portrait",
    image: "/abstract-face-portrait-artistic.jpg",
    floorPrice: "3.1",
    usdtPrice: "458015",
  },
  {
    id: 15,
    title: "Steampunk Mug",
    image: "/steampunk-coffee-mug-mechanical.jpg",
    floorPrice: "1.9",
    usdtPrice: "325241",
  },
  {
    id: 16,
    title: "Digital Portrait",
    image: "/placeholder.svg?height=400&width=350",
    floorPrice: "2.5",
    usdtPrice: "386026",
  },
]
