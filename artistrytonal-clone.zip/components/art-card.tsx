"use client"

import { useState } from "react"
import { cn } from "@/lib/utils"

interface ArtCardProps {
  title: string
  image: string
  floorPrice: string
  usdtPrice: string
}

export default function ArtCard({ title, image, floorPrice, usdtPrice }: ArtCardProps) {
  const [isHovered, setIsHovered] = useState(false)
  const [imageLoaded, setImageLoaded] = useState(false)

  return (
    <div
      className="group relative overflow-hidden rounded-xl bg-card transition-all duration-300 hover:scale-[1.02] hover:shadow-2xl"
      onMouseEnter={() => setIsHovered(true)}
      onMouseLeave={() => setIsHovered(false)}
    >
      <div className="relative aspect-[3/4] overflow-hidden bg-muted">
        {!imageLoaded && (
          <div className="absolute inset-0 flex items-center justify-center">
            <div className="h-8 w-8 animate-spin rounded-full border-4 border-muted-foreground/20 border-t-muted-foreground" />
          </div>
        )}
        <img
          src={image || "/placeholder.svg"}
          alt={title}
          className={cn(
            "h-full w-full object-cover transition-all duration-500",
            isHovered ? "scale-110" : "scale-100",
            imageLoaded ? "opacity-100" : "opacity-0",
          )}
          onLoad={() => setImageLoaded(true)}
        />

        <div className="absolute inset-0 bg-gradient-to-t from-black/60 via-transparent to-transparent opacity-0 transition-opacity duration-300 group-hover:opacity-100" />
      </div>

      <div className="space-y-3 p-4">
        <h3 className="text-lg font-medium text-card-foreground">{title}</h3>

        <div className="flex items-center justify-between">
          <div className="space-y-1">
            <p className="text-xs text-muted-foreground">Floor Price</p>
            <p className="text-sm font-semibold">{floorPrice} ETH</p>
          </div>
          <div className="text-right">
            <p className="text-xs text-muted-foreground">USDT</p>
            <p className="text-sm font-medium text-muted-foreground">{usdtPrice}</p>
          </div>
        </div>
      </div>

      <div
        className={cn(
          "absolute inset-0 rounded-xl ring-2 ring-primary/50 transition-opacity duration-300",
          isHovered ? "opacity-100" : "opacity-0",
        )}
      />
    </div>
  )
}
