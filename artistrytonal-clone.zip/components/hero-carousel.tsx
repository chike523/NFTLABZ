"use client"

import { useState, useEffect } from "react"
import { ChevronLeft, ChevronRight } from "lucide-react"
import { Button } from "@/components/ui/button"
import { cn } from "@/lib/utils"

const heroImages = [
  {
    id: 1,
    image: "/placeholder.svg?height=600&width=400",
    title: "Featured Art 1",
  },
  {
    id: 2,
    image: "/placeholder.svg?height=600&width=400",
    title: "Featured Art 2",
  },
  {
    id: 3,
    image: "/placeholder.svg?height=600&width=400",
    title: "Featured Art 3",
  },
  {
    id: 4,
    image: "/placeholder.svg?height=600&width=400",
    title: "Featured Art 4",
  },
  {
    id: 5,
    image: "/placeholder.svg?height=600&width=400",
    title: "Featured Art 5",
  },
  {
    id: 6,
    image: "/placeholder.svg?height=600&width=400",
    title: "Featured Art 6",
  },
  {
    id: 7,
    image: "/placeholder.svg?height=600&width=400",
    title: "Featured Art 7",
  },
]

export default function HeroCarousel() {
  const [currentIndex, setCurrentIndex] = useState(3)
  const [isAnimating, setIsAnimating] = useState(false)

  const nextSlide = () => {
    if (isAnimating) return
    setIsAnimating(true)
    setCurrentIndex((prev) => (prev + 1) % heroImages.length)
    setTimeout(() => setIsAnimating(false), 500)
  }

  const prevSlide = () => {
    if (isAnimating) return
    setIsAnimating(true)
    setCurrentIndex((prev) => (prev - 1 + heroImages.length) % heroImages.length)
    setTimeout(() => setIsAnimating(false), 500)
  }

  useEffect(() => {
    const interval = setInterval(nextSlide, 5000)
    return () => clearInterval(interval)
  }, [])

  const getVisibleSlides = () => {
    const slides = []
    for (let i = -3; i <= 3; i++) {
      const index = (currentIndex + i + heroImages.length) % heroImages.length
      slides.push({ ...heroImages[index], offset: i })
    }
    return slides
  }

  return (
    <div className="relative h-[400px] w-full overflow-hidden bg-gradient-to-b from-background to-background/50 py-8">
      <div className="absolute inset-0 flex items-center justify-center">
        <div className="relative flex h-full w-full items-center justify-center">
          {getVisibleSlides().map((slide, idx) => {
            const offset = slide.offset
            const isCenter = offset === 0

            return (
              <div
                key={`${slide.id}-${idx}`}
                className={cn("absolute transition-all duration-500 ease-out", isCenter ? "z-30" : "z-10")}
                style={{
                  transform: `translateX(${offset * 280}px) scale(${
                    isCenter ? 1.2 : Math.max(0.7, 1 - Math.abs(offset) * 0.15)
                  })`,
                  opacity: Math.max(0, 1 - Math.abs(offset) * 0.3),
                  filter: isCenter ? "none" : "brightness(0.6)",
                }}
              >
                <div className="relative h-[320px] w-[240px] overflow-hidden rounded-xl">
                  <img
                    src={slide.image || "/placeholder.svg"}
                    alt={slide.title}
                    className="h-full w-full object-cover"
                  />
                </div>
              </div>
            )
          })}
        </div>
      </div>

      <Button
        variant="ghost"
        size="icon"
        onClick={prevSlide}
        className="absolute left-4 top-1/2 z-40 h-10 w-10 -translate-y-1/2 rounded-full bg-background/80 hover:bg-background"
      >
        <ChevronLeft className="h-6 w-6" />
      </Button>

      <Button
        variant="ghost"
        size="icon"
        onClick={nextSlide}
        className="absolute right-4 top-1/2 z-40 h-10 w-10 -translate-y-1/2 rounded-full bg-background/80 hover:bg-background"
      >
        <ChevronRight className="h-6 w-6" />
      </Button>
    </div>
  )
}
