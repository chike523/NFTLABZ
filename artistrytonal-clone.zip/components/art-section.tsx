"use client"

import { Button } from "@/components/ui/button"
import ArtCard from "@/components/art-card"

interface ArtItem {
  id: number
  title: string
  image: string
  floorPrice: string
  usdtPrice: string
}

interface ArtSectionProps {
  title: string
  items: ArtItem[]
}

export default function ArtSection({ title, items }: ArtSectionProps) {
  return (
    <section className="space-y-6">
      <div className="flex items-center justify-between">
        <h2 className="text-3xl font-bold">{title}</h2>
        <Button variant="ghost" className="rounded-lg bg-muted px-6 hover:bg-muted/80">
          view all
        </Button>
      </div>

      <div className="grid grid-cols-1 gap-6 sm:grid-cols-2 lg:grid-cols-4">
        {items.map((item) => (
          <ArtCard key={item.id} {...item} />
        ))}
      </div>
    </section>
  )
}
