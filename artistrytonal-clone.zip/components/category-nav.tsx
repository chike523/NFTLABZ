"use client"

import { useState } from "react"
import { cn } from "@/lib/utils"

const categories = ["All", "Arts", "Gaming", "Membership", "PFPS", "Photography", "Exhibition"]

export default function CategoryNav() {
  const [activeCategory, setActiveCategory] = useState("All")

  return (
    <nav className="sticky top-16 z-40 w-full border-b border-border/40 bg-background/95 backdrop-blur supports-[backdrop-filter]:bg-background/60">
      <div className="container mx-auto px-4">
        <div className="flex gap-2 overflow-x-auto py-4 scrollbar-hide">
          {categories.map((category) => (
            <button
              key={category}
              onClick={() => setActiveCategory(category)}
              className={cn(
                "whitespace-nowrap rounded-lg px-4 py-2 text-sm font-medium transition-all duration-200",
                activeCategory === category
                  ? "bg-secondary text-secondary-foreground"
                  : "text-muted-foreground hover:bg-accent hover:text-accent-foreground",
              )}
            >
              {category}
            </button>
          ))}
        </div>
      </div>
    </nav>
  )
}
